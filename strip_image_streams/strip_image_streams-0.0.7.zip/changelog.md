
**<span style="color:#56adda">0.0.7</span>**
- Update FFmpeg helper
- Add platform declaration

**<span style="color:#56adda">0.0.6</span>**
- Update Plugin for Unmanic v2 PluginHandler compatibility

**<span style="color:#56adda">0.0.5</span>**
- Add some missing stream codecs from list of "image" video streams

**<span style="color:#56adda">0.0.4</span>**
- Limit plugin to only process files with a "video" mimetype

**<span style="color:#56adda">0.0.3</span>**
- Set the initial position in the plugin flow to highest priority

**<span style="color:#56adda">0.0.2</span>**
- Update Plugin for Unmanic v1 PluginHandler compatibility
- Update icon
- Add file test runner to check if files have image video streams to be removed

**<span style="color:#56adda">0.0.1</span>**
- Initial version
