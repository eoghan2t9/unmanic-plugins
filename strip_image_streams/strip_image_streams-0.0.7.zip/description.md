
This plugin does not modify 'data' or 'attachment' streams.

It only removes images stored as video streams.
