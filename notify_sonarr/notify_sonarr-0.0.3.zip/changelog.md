
**<span style="color:#56adda">0.0.3</span>**
- Improve logging
- Improve description

**<span style="color:#56adda">0.0.2</span>**
- Add ability to import episode into Sonarr on task complete

**<span style="color:#56adda">0.0.1</span>**
- Initial version
