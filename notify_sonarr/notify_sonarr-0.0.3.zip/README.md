# Notify Sonarr

plugin for [Unmanic](https://github.com/Unmanic)
